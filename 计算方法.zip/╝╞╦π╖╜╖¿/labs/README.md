## 计算方法Labs

2019秋 陈先进老师

古宜民 (github.com/ustcpetergu)

lab1 求和差

lab2 Lagrange插值

lab3 复化数值积分

lab4 非线性方程求根

lab5 迭代法解线性代数方程组